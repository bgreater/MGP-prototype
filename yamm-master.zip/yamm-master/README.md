# Yamm #


This is *Yet another megamenu for [Bootstrap](http://twitter.github.io/bootstrap/)* from Twitter.   
   
In few words, a megamenu that uses the standard navbar markup and the fluid grid system classes from Bootstrap. Work for fixed and responsive layout and has the facility to include (almost) any Bootstrap elements.


`See demo for online examples and documentation`

#[Demo](http://geedmo.github.io/yamm)



